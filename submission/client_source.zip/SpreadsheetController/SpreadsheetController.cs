﻿using System;

namespace SpreadsheetController
{
    public class Class1
    {
    }
}
